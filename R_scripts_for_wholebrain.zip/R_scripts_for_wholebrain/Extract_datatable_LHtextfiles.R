                ##Script for extracting data and analyse Learned Helplessness text filesin one table##

file_ext<-function (x) 
{
  pos <- regexpr("\\.([[:alnum:]]+)$", x)
  ifelse(pos > -1L, substring(x, pos + 1L), "")
}


get.files<-function (x, type = "txt") 
{
  text.files <- which(file_ext(dir(x)) == type)
  text.files <- paste(path.expand(x), dir(x)[text.files], 
                      sep = "/")
  return(text.files)
}


#stats function
min.mean.sd.max <- function(x) {
  r <- c(min(x), mean(x) - sd(x), mean(x), mean(x) + sd(x), max(x))
  names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
  r
}
 

library(readxl)
library(data.table)
library(dplyr)
library(tidyr)
library(magrittr)
library(ggplot2)  
library(scales)
#library(tidyverse)  # data manipulation
library(cluster)    # clustering algorithms
library(factoextra) # clustering algorithms & visualization


                                         

                                          ##MASTER CODE FOR ALL THE FOLDERS

masterfolder<-"C:/Users/Mangana/Downloads/LH_7days/"
list_folder<-list.dirs(masterfolder)

remove(df_LH, df_LH_merged)
#choose the table format vertical or wide, first wide then vertical
tbtype <-"wide"

for (i in list_folder) {
  
  print(i)
  folder<-i
  list_files<-get.files(folder)
  head(list_files)
  length(list_files)
  list_id<- character()
  list_group<-character()
  
  if (tbtype =="vertical") {
    print("Building long table")
    file1<-read.delim2(list_files[1], sep = ":")
    id<-as.character(file1[3,2])
    group<-as.character(file1[5,2])
    list_id[1]<-id
    list_group[1]<-group
    file1<-file1[16:45,1:2]
    file1$C<-as.character(file1$C)
    file1$C<-as.double(file1$C)
    master.data_EL<-file1
    names(master.data_EL)<-c("trial","sec")
    master.data_EL$animal<-id
    master.data_EL$group<-group
    
    for (i in 2:length(list_files)) {
      print(list_files[i])
      escape_latency_table <-read.delim2(list_files[i], sep = ":")
      id<-as.character(escape_latency_table[3,2])
      group<-as.character(escape_latency_table[5,2])
      escape_latency_table <-escape_latency_table[16:45,1:2]
      escape_latency_table$C<-as.character(escape_latency_table$C)
      escape_latency_table$C<-as.double(escape_latency_table$C)
      names(escape_latency_table)<-c("trial","sec")
      escape_latency_table$animal<-id
      escape_latency_table$group<-group
      master.data_EL<-rbind(master.data_EL,escape_latency_table)
      #Remember to replace the "11" in latency with "10"
      master.data_EL$sec[grepl("11",master.data_EL$sec)]<-as.numeric("10")
      table_EL1.long<- master.data_EL
    }
  } else {
    print("Building wide table")
    file1<-read.delim2(list_files[1], sep = ":")
    id<-as.character(file1[3,2])
    list_id[1]<-id
    file1<-file1[16:45,1:2]
    file1$C<-as.character(file1$C)
    file1$C<-as.double(file1$C)
    master.data_EL<-file1
    names(master.data_EL)<-c("trial","sec")
    #Remember to replace the "11" in latency with "10"
    master.data_EL$sec[grepl("11",master.data_EL$sec)]<-as.numeric("10")
    
    for (i in 2:length(list_files)) {
      print(list_files[i])
      escape_latency_table <-read.delim2(list_files[i], sep = ":")
      id<-as.character(escape_latency_table[3,2])
      list_id[i]<-id
      escape_latency_table <-escape_latency_table[16:45,1:2]
      escape_latency_table$C<-as.character(escape_latency_table$C)
      escape_latency_table$C<-as.double(escape_latency_table$C)
      names(escape_latency_table)<-c("trial","sec")
      escape_latency_table$sec[grepl("11",escape_latency_table$sec)]<-as.numeric("10")
      master.data_EL<- merge(master.data_EL,escape_latency_table, by=c("trial"))
      
    }
    master.data_EL<-master.data_EL[,-1]
    names(master.data_EL)<-list_id
    table_EL1<- master.data_EL
  }
} 

  #Mean calculation of Escape Latency in long table
  Escape_Latency<-aggregate(table_EL1.long[, 2], list(table_EL1.long$animal), mean)
  names(Escape_Latency)[1]<-"animal"
  Escape_Latency$x<-round(Escape_Latency$x, 2)
  names(Escape_Latency)[2]<-"Latency"
  
  #count of avoidances and failures
  Avoidance <- table_EL1.long %>% filter(sec==0)
  avoidance_count<-Avoidance %>% group_by(animal) %>% count()
  Failures <- table_EL1.long %>% filter(sec==10)
  failures_mice<-Failures %>% group_by(animal) %>% count()
  failures_mice<-as.data.frame(failures_mice)
  names(failures_mice)[2]<-"Failures"
  
  #create table fields for mice with 0 Failures
  no_failure_mice<-aggregate(table_EL1.long[, 2], list(table_EL1.long$animal), max)%>%filter(x<10)
  no_failure_mice$x<-0
  names(no_failure_mice)<-names(failures_mice)
  no_failure_mice<-as.data.frame(no_failure_mice)
  Failures_total<- rbind(failures_mice,no_failure_mice)
  
  #merge escape latency data with number of Failures for LH clustering
  dim(Failures_total)
  dim(Escape_Latency)
  df_LH<-merge(Failures_total,Escape_Latency)
  df_LH$Wave<-NA
  df_LH$Wave<-as.character(basename(folder))
  df_LH$Group<-NA
  df_LH$Group<-lapply(df_LH$animal, function(x) as.character(master.data_EL$group[match(x, master.data_EL$animal)]))
  
  ##to merge df of different waves
  if (exists('df_LH_merged')) {
    print("dataframe exist!")
    df_LH_merged<-rbind(df_LH_merged, df_LH)
  }else{
    df_LH_merged<-df_LH # for the first file
  }
  




                                       ###TO RUN ON 1 FOLDER


folder<-"C:/Users/Mangana/Documents/LH_7days/WAVE1/"
list_files<-get.files(folder)
head(list_files)
length(list_files)
list_id<- character()
list_group<-character()

#choose the table format vertical or wide, first wide then vertical
tbtype <-readline(prompt = "which table you want? ")

if (tbtype =="vertical") {
  print("Building long table")
  file1<-read.delim2(list_files[1], sep = ":")
  id<-as.character(file1[3,2])
  group<-as.character(file1[5,2])
  list_id[1]<-id
  list_group[1]<-group
  file1<-file1[16:45,1:2]
  file1$C<-as.character(file1$C)
  file1$C<-as.double(file1$C)
  master.data_EL<-file1
  names(master.data_EL)<-c("trial","sec")
  master.data_EL$animal<-id
  master.data_EL$group<-group
  
   for (i in 2:length(list_files)) {
    print(list_files[i])
    escape_latency_table <-read.delim2(list_files[i], sep = ":")
    id<-as.character(escape_latency_table[3,2])
    group<-as.character(escape_latency_table[5,2])
    escape_latency_table <-escape_latency_table[16:45,1:2]
    escape_latency_table$C<-as.character(escape_latency_table$C)
    escape_latency_table$C<-as.double(escape_latency_table$C)
    names(escape_latency_table)<-c("trial","sec")
    escape_latency_table$animal<-id
    escape_latency_table$group<-group
    master.data_EL<-rbind(master.data_EL,escape_latency_table)
    #Remember to replace the "11" in latency with "10"
    master.data_EL$sec[grepl("11",master.data_EL$sec)]<-as.numeric("10")
    table_EL1.long<- master.data_EL
  }
} else {
  print("Building wide table")
  file1<-read.delim2(list_files[1], sep = ":")
  id<-as.character(file1[3,2])
  list_id[1]<-id
  file1<-file1[16:45,1:2]
  file1$C<-as.character(file1$C)
  file1$C<-as.double(file1$C)
  master.data_EL<-file1
  names(master.data_EL)<-c("trial","sec")
  #Remember to replace the "11" in latency with "10"
  master.data_EL$sec[grepl("11",master.data_EL$sec)]<-as.numeric("10")
  
  for (i in 2:length(list_files)) {
    print(list_files[i])
    escape_latency_table <-read.delim2(list_files[i], sep = ":")
    id<-as.character(escape_latency_table[3,2])
    list_id[i]<-id
    escape_latency_table <-escape_latency_table[16:45,1:2]
    escape_latency_table$C<-as.character(escape_latency_table$C)
    escape_latency_table$C<-as.double(escape_latency_table$C)
    names(escape_latency_table)<-c("trial","sec")
    escape_latency_table$sec[grepl("11",escape_latency_table$sec)]<-as.numeric("10")
    master.data_EL<- merge(master.data_EL,escape_latency_table, by=c("trial"))
    
  }
  master.data_EL<-master.data_EL[,-1]
  names(master.data_EL)<-list_id
  table_EL1<- master.data_EL
}
  

#reshape table from long to wide if you did not rerun the previous loop with !vertical
EL_dataframe_wide<- pivot_wider(master.data_EL, names_from = c(animal,group), values_from = sec)
EL_dataframe_wide<-EL_dataframe_wide[,-1]
table_EL1<- EL_dataframe_wide

#plotting histogram of latency distribution for each mouse based on table format wide
table_EL1 %>% gather() %>% head()

ggplot(gather(table_EL1), aes(value)) + 
     geom_histogram(stat = "count") +
     scale_x_binned() +
     facet_wrap(~key, scales = 'fixed')


#add row names as variables for counting trials if needed
dim.data.frame(table_EL1.long)
table_EL1.long<-dplyr::add_rownames(table_EL1.long)
colnames(table_EL1.long)[1]<-"trial"


#Mean calculation of Escape Latency in long table
Escape_Latency<-aggregate(table_EL1.long[, 2], list(table_EL1.long$animal), mean)
names(Escape_Latency)[1]<-"animal"
Escape_Latency$x<-round(Escape_Latency$x, 2)
names(Escape_Latency)[2]<-"Latency"

#count of avoidances and failures
Avoidance <- table_EL1.long %>% filter(sec==0)
avoidance_count<-Avoidance %>% group_by(animal) %>% count()
Failures <- table_EL1.long %>% filter(sec==10)
failures_mice<-Failures %>% group_by(animal) %>% count()
failures_mice<-as.data.frame(failures_mice)
names(failures_mice)[2]<-"Failures"

#create table fields for mice with 0 Failures
no_failure_mice<-aggregate(table_EL1.long[, 2], list(table_EL1.long$animal), max)%>%filter(x<10)
no_failure_mice$x<-0
names(no_failure_mice)<-names(failures_mice)
no_failure_mice<-as.data.frame(no_failure_mice)
Failures_total<- rbind(failures_mice,no_failure_mice)

#merge escape latency data with number of Failures for LH clustering
dim(Failures_total)
dim(Escape_Latency)
df_LH<-merge(Failures_total,Escape_Latency)
df_LH$Wave<-NA
df_LH$Wave<-as.character(basename(folder))
df_LH$Group<-NA
df_LH$Group<-lapply(df_LH$animal, function(x) as.character(table_EL1.long$group[match(x, table_EL1.long$animal)]))
df_LH$Group<- unlist(df_LH$Group)
##to merge df of different waves
df_LH_merged<-df_LH # for the first file
df_LH_merged<-rbind(df_LH_merged, df_LH)
#make sure your groups name are consistent and split the table in control and shocked if need it
df_LH_merged_control<-df_LH_merged[!(df_LH_merged$Group=="SHOCKED"),]
df_LH_merged_shocked<-df_LH_merged[df_LH_merged$Group=="SHOCKED",]

##to merge df of different waves
df_LH_merged<-df_LH # for the first file
df_LH_merged<-rbind(df_LH_merged, df_LH)


#Select by group and filter by count n, just qualitative split, clustering need it
Helpless_mice<- Failures_total %>% filter(Failures>= 11) %>% select(animal)
Resilient_mice<-Avoidance %>% group_by(animal)%>% tally %>% filter(n>= 10) %>% select(animal)

                                                        ##PLOTTING


#few animals
library(grid)
df<-table_EL1.long
h <- ggplot(df, aes(trial, sec, group=1)) + geom_point(aes(color=animal))+ geom_line() + facet_wrap(~animal, ncol=1)
print(h, vp = viewport(layout.pos.row = 1, layout.pos.col = 1))
#multi col layout for more animals
dim_df<-dim.data.frame(df)[1]
half_df<- dim_df/2
half_df_1<- half_df + 1
h <- ggplot(df[1:half_df,], aes(trial, sec, group=1)) + geom_point(aes(color=animal))+ geom_line() + facet_wrap(~animal, ncol=1)
g <- ggplot(df[half_df_1:dim_df,], aes(trial, sec, group=1)) + geom_point(aes(color=animal))+ geom_line() + facet_wrap(~animal, ncol=1)
pushViewport(viewport(layout = grid.layout(1, 2))) 
print(h, vp = viewport(layout.pos.row = 1, layout.pos.col = 1))
print(g, vp = viewport(layout.pos.row = 1, layout.pos.col = 2))


