###

acronym.from.parent<-function (x) 
{
  unlist(lapply(x, function(y) {
    if (length(which(atlasOntology$parent == y)) != 0) {
      return(as.character(atlasOntology$acronym[which(atlasOntology$parent == 
                                                   y)]))
    }
    else {
      return(NA)
    }
  }))
}


NORM.VOLUME<-function (dataset, bilateral = TRUE, aggregate = NULL) 
{
  if (!bilateral) {
    counts <- table(dataset$acronym, dataset$right.hemisphere)
  }
  else {
    counts <- table(dataset$acronym)
  }
  parent.regions <- row.names(counts)
  if (!is.null(aggregate)) {
    parent.regions <- row.names(counts)
    parent.regions[parent.regions %in% get.sub.structure(aggregate)] <- aggregate
  }
  volume <- ontology$volume[match(parent.regions, ontology$acronym)]
  while (any(is.na(volume)==TRUE)) {
    parent.regions[is.na(volume)==TRUE] <- get.acronym.parent(get.acronym.parent(parent.regions[is.na(volume)==TRUE]))
    volume <- ontology$volume[match(parent.regions, ontology$acronym)]
  }
  counts <- sweep(counts, 1, volume * (1 - 0.5 * bilateral), 
                  FUN = "/")
  return(counts)
}


library(dplyr)
library(tidyr)
library(readr)


write.table(atlasOntology, file = "Atlas_Ontology.csv", row.names=FALSE, na="",col.names=TRUE, sep=",")

#create masterdata for trap and cfos separately and add animal names
setwd("F:/LH_ASDS/Done/LH_ASDS_analysis/")
datasets.cfos<- list.files(pattern = "*cfos_data.csv")
length(datasets.cfos)
datasets.trap<-list.files(pattern = "*trap_data.csv")
length(datasets.trap)
master_cfos_data<-read_csv(datasets.cfos[1])
master_cfos_data$animal<-substring(datasets.cfos[1], 1,7)
master_trap_data<-read_csv(datasets.trap[1])
master_trap_data$animal<-substring(datasets.trap[1], 1,7)

#if you need to add new animals datasets to masterdata already created
for (i in 2:length(datasets.cfos)) {
  datasets_new <- read_csv(datasets.cfos[i])
  datasets_new$animal<-substring(datasets.cfos[i], 1,7)
  master_cfos_data<-rbind(master_cfos_data,datasets_new)
}

for (i in 2:length(datasets.trap)) {
  datasets_new <- read_csv(datasets.trap[i])
  datasets_new$animal<-substring(datasets.trap[i], 1,7)
  master_trap_data<-rbind(master_trap_data,datasets_new)
}


#if you need to reimport the csv with the bing datasets from more animals
master_trap_data <- read_csv("C:/Users/Mangana/Downloads/master_trap_data.csv")
View(master_trap_data_AP)

master_cfos_data <- read_csv("C:/Users/Mangana/Downloads/master_cfos_data.csv")
View(master_cfos_data_AP)


#cleaning of master.datasets i.a. removing NA fields
master_cfos_data<- master_cfos_data[!(master_cfos_data$color == '#000000'),]
master_trap_data<- master_trap_data[!(master_trap_data$color == '#000000'),]

#if you want to limit to a specific AP range
master_trap_data_APlimited<-master_trap_data %>% filter(AP< 2.8) %>% filter(AP> -5)
master_trap_data_APlimited_unique<-unique(master_trap_data_APlimited, by = "colname")
master_cfos_data_APlimited<-master_cfos_data %>% filter(AP< 2.8) %>% filter(AP> -5)
master_cfos_data_APlimited_unique<-unique(master_cfos_data_APlimited, by = "colname")

#Creat group col for both phenothype and exp and populate with the correct value
master_trap_data$group<- NA
master_trap_data$sex<- NA
master_trap_data$phenotype<- NA
master_trap_data$group[grepl("D",master_trap_data$animal)]<-"shocked"
master_trap_data$group[grepl("C",master_trap_data$animal)]<-"control"
master_cfos_data$group[grepl("D",master_cfos_data$animal)]<-"shocked"
master_cfos_data$group[grepl("C",master_cfos_data$animal)]<-"control"

master_trap_data$sex[grepl("F",master_trap_data$animal)]<-"female"
master_trap_data$sex[grepl("M",master_trap_data$animal)]<-"male"
master_cfos_data$sex[grepl("F",master_cfos_data$animal)]<-"female"
master_cfos_data$sex[grepl("M",master_cfos_data$animal)]<-"male"

#phenotype attribution only for the signal observed
master_trap_data$phenotype[grepl("C",master_trap_data$animal)]<-"control"
master_trap_data$phenotype[master_trap_data$animal=="D006_M3"]<-"r"
master_trap_data$phenotype[master_trap_data$animal=="D011_F1"]<-"h"
master_cfos_data$phenotype[grepl("C",master_cfos_data$animal)]<-"control"
master_cfos_data$phenotype[master_cfos_data$animal=="D002_F1"]<-"r"
master_cfos_data$phenotype[master_cfos_data$animal=="D001_M1"]<-"s"


#better formula for the counting, sum is needed because it adds the count instead of counting lines
master.counted.trap<- master_trap_data %>% group_by(animal,AP,acronym, phenotype) %>% summarise(total_count=n(), groups='drop')
master.counted.cfos<- master_cfos_data %>% group_by(animal,AP,acronym, phenotype) %>% summarise(total_count=n(), groups='drop')
master.counted_stats<-aggregate(total_count~acronym, data = master.counted, mean)
master.counted_stats<-aggregate(total_count~acronym, data = master.counted, var)
master.counted_stats<-aggregate(total_count~acronym, data = master.counted, st_dev)
master.counted_sum.trap<-aggregate(master.counted.trap$total_count, by=list(master.counted.trap$animal, master.counted.trap$acronym), sum)
master.counted_sum.cfos<-aggregate(master.counted.cfos$total_count, by=list(master.counted.cfos$animal, master.counted.cfos$acronym), sum)
colnames(master.counted_sum.trap)[1]<-"animal"
colnames(master.counted_sum.trap)[2]<-"region"
colnames(master.counted_sum.trap)[3]<-"count"
colnames(master.counted_sum.cfos)[1]<-"animal"
colnames(master.counted_sum.cfos)[2]<-"region"
colnames(master.counted_sum.cfos)[3]<-"count"
master.counted_sum.trap$norm<-NA
master.counted_sum.trap$parent<-NA
master.counted_sum.trap$macroarea<-NA
master.counted_sum.cfos$norm<-NA
master.counted_sum.cfos$parent<-NA
master.counted_sum.cfos$macroarea<-NA
#remove the regions that are for neurons on borders and classified in general areas like grey
c<-c("SEZ","AQ", "c", "grey","fiber tracts","MB", "HB", "IB","VL","IVF", "V3","V4", "CTX", "ri", "fxs", "HPF", "OLF", "Isocortex", "CNU","CA","DG","IG","FC")
master.counted_sum.cfos<-master.counted_sum.cfos[!(master.counted_sum.cfos$region %in% c),]
master.counted_sum.trap<-master.counted_sum.trap[!(master.counted_sum.trap$region %in% c),]
#to test first
master_test1<-master.counted_sum.trap[!grepl("nerve", master.counted_sum.trap$region),]
master_test1<-master.counted_sum.trap[!grepl("tract", master.counted_sum.trap$region),]

#save those datatables
write.table(master.counted.cfos, file = "master.counted.cfos.csv", row.names=FALSE, na="",col.names=TRUE, sep=",")
write.table(master.counted.trap, file = "master.counted.trap.csv", row.names=FALSE, na="",col.names=TRUE, sep=",")
write.table(master.counted_sum.cfos, file = "master.counted_sum.cfos.csv", row.names=FALSE, na="",col.names=TRUE, sep=",")
write.table(master.counted_sum.trap, file = "master.counted_sum.trap.csv", row.names=FALSE, na="",col.names=TRUE, sep=",")

for (i in master.counted_sum.trap$region) {
print(i)
master.counted_sum.trap$parent[grepl(i, master.counted_sum.trap$region)]<- Atlas_Ontology$parent[Atlas_Ontology$acronym==i]
}
for (i in master.counted_sum.cfos$region) {
  print(i)
  master.counted_sum.cfos$parent[grepl(i, master.counted_sum.cfos$region)]<- Atlas_Ontology$parent[Atlas_Ontology$acronym==i]
}


savehistory("~/summary_masterdataset.Rhistory")

master.counted_sum.trap$parent<-as.numeric(master.counted_sum.trap$parent)
master.counted_sum.cfos$parent<-as.numeric(master.counted_sum.cfos$parent)
master.counted_sum.trap$count<-as.numeric(master.counted_sum.trap$count)
master.counted_sum.cfos$count<-as.numeric(master.counted_sum.cfos$count)

df_trap_parent_count <- master.counted_sum.trap%>% group_by(animal, parent) %>% summarise(countsum=sum(count))
df_cfos_parent_count <- master.counted_sum.cfos%>% group_by(animal, parent) %>% summarise(countsum=sum(count))

#If you would like to work with the nested datasets
master.counted_sum.trap2<- master.counted_sum.trap %>% group_by(parent) %>% nest()
master.counted_sum.cfos2<- master.counted_sum.cfos %>% group_by(parent) %>% nest()

#importing the parental merging csv
library(readr)
parental_aggregates <- read_csv("parental_aggregates.csv")
parental_aggregates$Parental<-as.numeric(parental_aggregates$Parental)

#add the  merging of parental areas and collapse them
df_trap_parent_count$Merging_Area<-NA
for (i in df_trap_parent_count$parent) {
  print(i)
  df_trap_parent_count$Merging_Area[grepl(i, df_trap_parent_count$parent)]<- parental_aggregates$Merging_Area[parental_aggregates$Parental==i]
}

df_cfos_parent_count$Merging_Area<-NA
for (i in df_cfos_parent_count$parent) {
  print(i)
  df_cfos_parent_count$Merging_Area[grepl(i, df_cfos_parent_count$parent)]<- parental_aggregates$Merging_Area[parental_aggregates$Parental==i]
}

df_trap_parent_count <- df_trap_parent_count%>% group_by(animal, Merging_Area) %>% summarise(countsum1=sum(countsum))
df_cfos_parent_count <- df_cfos_parent_count%>% group_by(animal, Merging_Area) %>% summarise(countsum1=sum(countsum))

#add the normalization here

#if you want to reorder the df columns for macroareas
vector_reorder<-parental_aggregates$Merging_Area
vector_reorder_df<-df_cfos_parent_count$Merging_Area
reorder_idx<-match(vector_reorder, vector_reorder_df)
reorder_idx<-unique(reorder_idx)
reorder_idx<-reorder_idx[!is.na(reorder_idx) ==TRUE] #Use this vector below with df for reorder the matrices

#make wide format tables for pearson correlation
df_trap_parent_count_wide<-pivot_wider(df_trap_parent_count, names_from = c(Merging_Area),values_from = countsum1)
df_cfos_parent_count_wide<-pivot_wider(df_cfos_parent_count, names_from = c(Merging_Area),values_from = countsum1)
write.table(df_trap_parent_count_wide, file = "master.LHASDS.trap.sum.byparent_wide.csv", row.names=TRUE, na="",col.names=TRUE, sep=",")
write.table(df_cfos_parent_count_wide, file = "master.LHASDS.cfos.sum.byparent_wide.csv", row.names=TRUE, na="",col.names=TRUE, sep=",")
df_trap_parent_count_wide_control<-df_trap_parent_count_wide[1:5,]
df_trap_parent_count_wide_shocked<-df_trap_parent_count_wide[6:14,]
df_cfos_parent_count_wide_control<-df_cfos_parent_count_wide[1:5,1:79]#empty clm
df_cfos_parent_count_wide_defeated<-df_cfos_parent_count_wide[6:14,]

#Matrix correlations and Heat Maps (Pearson)
df_trap_parent_count_wide[is.na(df_trap_parent_count_wide)]<-0
df1<-df_trap_parent_count_wide
df1<-df1[,-1]
#colnames(df1)<-acronym.from.parent(colnames(df1))
res_trap<-cor(df1)

df_cfos_parent_count_wide[is.na(df_cfos_parent_count_wide)]<-0
df2<-df_cfos_parent_count_wide
df2<-df2[,-1]
#colnames(df2)<-acronym.from.parent(colnames(df2))
res_cfos<-cor(df2)

df_trap_parent_count_wide_control[is.na(df_trap_parent_count_wide_control)]<-0
df3<-df_trap_parent_count_wide_control
df3<-df3[,-1]
#colnames(df3)<-acronym.from.parent(colnames(df3))
res_trap_ctr<-cor(df3)
df3_reordered<-df3[reorder_idx]
res_trap_ctr_reorder<-cor(df3_reordered)

df_trap_parent_count_wide_shocked[is.na(df_trap_parent_count_wide_shocked)]<-0
df4<-df_trap_parent_count_wide_shocked
df4<-df4[,-1]
#colnames(df4)<-acronym.from.parent(colnames(df4))
res_trap_shocked<-cor(df4)
df4_reordered<-df4[reorder_idx]
res_trap_shocked_reorder<-cor(df4_reordered)


df_cfos_parent_count_wide_control[is.na(df_cfos_parent_count_wide_control)]<-0
df5<-df_cfos_parent_count_wide_control
df5<-df5[,-1]
#colnames(df5)<-acronym.from.parent(colnames(df5))
res_cfos_control<-cor(df5)
df5_reordered<-df5[reorder_idx]
res_cfos_control_reorder<-cor(df5_reordered)


df_cfos_parent_count_wide_defeated[is.na(df_cfos_parent_count_wide_defeated)]<-0
df6<-df_cfos_parent_count_wide_defeated
df6<-df6[,-1]
#colnames(df6)<-acronym.from.parent(colnames(df6))
res_cfos_defeated<-cor(df6)
df6_reordered<-df6[reorder_idx]
res_cfos_defeated_reorder<-cor(df6_reordered)

#split for phenotype the shocked and defeated
df_trap_parent_count_wide_shocked$Phenotype<-NA
df_trap_parent_count_wide_shocked$Phenotype[1]<-"Resilient"
df_trap_parent_count_wide_shocked$Phenotype[2]<-"Helpless"#or write a vector of indexes first
df7<-split(df7, f=df7$Phenotype)[['Resilient']]
df8<-split(df7, f=df7$Phenotype)[['Helpless']]
df7<-df7%>%dplyr::select(!(Phenotype))
df8<-df8%>%dplyr::select(!(Phenotype))
df7<-df7[,-1]
df8<-df8[,-1]
res_trap_helpless<-cor(df7)
res_trap_resilient<-cor(df8)


#Heatmaps, 2 methods
library(pheatmap)
pheatmap(df3)#first raw plotting with clustering for rows and clms
Breaks <- seq(min(c(res_trap_ctr, res_trap_shocked)), max(c(res_trap_ctr, res_trap_shocked)), length = 100)
pheatmap(res_trap_ctr, legend = TRUE, fontsize =7,cellwidth =7, cellheight =7,breaks = Breaks)
pheatmap(res_trap_shocked, legend = TRUE, fontsize =7,cellwidth =7, cellheight =7, breaks = Breaks)
Breaks <- seq(min(c(res_cfos_control, res_cfos_defeated)), max(c(res_cfos_control, res_cfos_defeated)), length = 100)
pheatmap(res_cfos_control, legend = TRUE, fontsize =7,cellwidth =7, cellheight =7, breaks = Breaks)
pheatmap(res_cfos_defeated, legend = TRUE, fontsize =6,cellwidth =6, cellheight =6, breaks = Breaks)

#without clustering
Breaks <- seq(min(c(res_trap_ctr, res_trap_shocked)), max(c(res_trap_ctr, res_trap_shocked)), length = 100)
pheatmap(res_trap_ctr,cluster_rows=FALSE,cluster_cols=FALSE,legend = TRUE,fontsize =7,cellwidth =7, cellheight =7,breaks = Breaks)
pheatmap(res_trap_shocked,cluster_rows=FALSE,cluster_cols=FALSE,legend = TRUE,fontsize =7,cellwidth =7, cellheight =7, breaks = Breaks)
Breaks <- seq(min(c(res_cfos_control, res_cfos_defeated)),max(c(res_cfos_control, res_cfos_defeated)), length = 100)
pheatmap(res_cfos_control,cluster_rows=FALSE, cluster_cols=FALSE,legend = TRUE,fontsize =7,cellwidth =7, cellheight =7, breaks = Breaks)
pheatmap(res_cfos_defeated,cluster_rows=FALSE, cluster_cols=FALSE,legend = TRUE,fontsize =6,cellwidth =6, cellheight =6, breaks = Breaks)
#reordered
Breaks <- seq(min(c(res_trap_ctr_reorder, res_trap_shocked_reorder)), max(c(res_trap_ctr_reorder, res_trap_shocked_reorder)), length = 100)
pheatmap(res_trap_ctr_reorder,cluster_rows=FALSE,cluster_cols=FALSE,legend = TRUE,fontsize =7,cellwidth =7, cellheight =7,breaks = Breaks)
pheatmap(res_trap_shocked_reorder,cluster_rows=FALSE,cluster_cols=FALSE,legend = TRUE,fontsize =7,cellwidth =7, cellheight =7, breaks = Breaks)
Breaks <- seq(min(c(res_cfos_control_reorder, res_cfos_defeated_reorder)),max(c(res_cfos_control_reorder, res_cfos_defeated_reorder)), length = 100)
pheatmap(res_cfos_control_reorder,cluster_rows=FALSE, cluster_cols=FALSE,legend = TRUE,fontsize =7,cellwidth =7, cellheight =7, breaks = Breaks)
pheatmap(res_cfos_defeated_reorder,cluster_rows=FALSE, cluster_cols=FALSE,legend = TRUE,fontsize =6,cellwidth =6, cellheight =6, breaks = Breaks)



library(Hmisc)
as.matrix(df3)
col<- colorRampPalette(c("yellow", "orange", "red"))(100)
heatmap(x = res_trap_ctr, col = col, symm = TRUE)
heatmap(x = res_trap_ctr, col = col, symm = TRUE, Rowv = NA)

as.matrix(df4)
col<- colorRampPalette(c("yellow", "orange", "red"))(100)
heatmap(x = res_trap_shocked, col = col, symm = TRUE, Rowv = NA, cexRow = 0.5, cexCol = 0.5)

as.matrix(df5)
col<- colorRampPalette(c("yellow", "orange", "red"))(100)
heatmap(x = res_cfos_control, col = col, symm = TRUE, Rowv = NA, cexRow = 0.5, cexCol = 0.5)

as.matrix(df6)
col<- colorRampPalette(c("yellow", "orange", "red"))(100)
heatmap(x = res_cfos_defeated, col = col, symm = TRUE, Rowv = NA, cexRow = 0.5, cexCol = 0.5)



##plot only the significant correlation p<0.05 with the Hmisc library
r = rcorr(as.matrix(df8))$r
# calculate p values
p = rcorr(as.matrix(df8))$P

#function to extrapolate the r and p values
flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}

matrix_df8_r_pvalue<-flattenCorrMatrix(r,p)
matrix_df8_r_pvalue<-matrix_df8_r_pvalue[(matrix_df8_r_pvalue$p<0.05),]

unique(matrix_df5_r_pvalue$row)%>%length()
#if you need to change one value in the matrix_r_p
levels(matrix_df7_r_pvalue$row)[grepl("EP",levels(matrix_df7_r_pvalue$row))]<-"BLAcomplex"
levels(matrix_df7_r_pvalue$column)[grepl("EP",levels(matrix_df7_r_pvalue$column))]<-"BLAcomplex"

#to plot with pheatmap only the significative:
list_restrapcorr<-ls(envir=.GlobalEnv, pattern = "res_trap" )
list_rescfoscorr<-ls(envir=.GlobalEnv, pattern = "res_cfos" )
list_rescorr<-c(list_restrapcorr, list_rescfoscorr)
#to remove specific res
list_rescorr<-list_rescorr[-5]

Breaks <- seq(min(c(res_trap_ctr, res_trap_shocked, res_cfos_control,res_cfos_defeated)), max(c(res_trap_ctr, res_trap_shocked, res_cfos_control,res_cfos_defeated)), length = 100)

#no clustering
for (i in list_rescorr) {
  print(i)
  res1<-get(i)
  res1[ abs(res1) < 0.85] <- 0
  diag(res1)<-0
  filename=paste0(i,"_sign_nocluster",".png")
  png(filename, width = 1538, height = 902)
  pheatmap(res1,cluster_rows=FALSE, cluster_cols=FALSE,legend = TRUE,fontsize =7,cellwidth =7, cellheight =7, breaks = Breaks, color = colorRampPalette(c("blue", "white", "red"))(100))
  dev.off()
}

#clustering
for (i in list_rescorr) {
  print(i)
  res1<-get(i)
  res1[ abs(res1) < 0.85] <- 0
  diag(res1)<-0
  filename=paste0(i,"_sign_samescale",".png")
  png(filename, width = 1538, height = 902)
  pheatmap(res1,legend = TRUE,fontsize =7,cellwidth =7, cellheight =7, breaks = Breaks,  color = colorRampPalette(c("blue", "white", "red"))(100))
  dev.off()
}


##plot network
library(igraph)

res1[ abs(res1) < 0.95] <- 0
network <- graph_from_adjacency_matrix( res1, weighted=T, mode="undirected", diag=F)

par(mfrow=c(2,2), mar=c(1,1,1,1))
plot(network, layout=layout.sphere, main="sphere")
plot(network, layout=layout.circle, main="circle")
plot(network, layout=layout.random, main="random")
plot(network, layout=layout.fruchterman.reingold, main="fruchterman.reingold")

for (i in list_rescorr) {
  print(i)
  res1<-get(i)
  res1[ abs(res1) < 0.95] <- 0
  diag(res1)<-0
  filename=paste0(i,"_network_sign",".png")
  png(filename, width = 1538, height = 902)
  network <- graph_from_adjacency_matrix( res1, weighted=T, mode="undirected", diag=F)
  plot(network, layout=layout.sphere, main="sphere")
  #plot(network, layout=layout.fruchterman.reingold, main="fruchterman.reingold")
  plot(network, layout=layout.random, main="random")
  dev.off()
}
