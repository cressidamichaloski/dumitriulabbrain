
library(dplyr)
library(tidyr)
library(readr)

#add the animal name in column one
datasets$animal<-"C007_F1"

#save as Excel spread.sheet the datatable created
write.table(datasets, file='C007_F1_TRAP_data.csv', sep=',', row.names =FALSE)
write.table(datasets, file='C007_F1_CFOS_data.csv', sep=',', row.names =FALSE)