##Plotting multiple 3D brain structures

library(cocoframer)
library(purrr)
library(rgl)

structures <- c("root","PAG","VTA")
mesh_list <- map(structures, ccf_2017_mesh)
names(mesh_list) <- structures
plot_ccf_meshes(mesh_list,
                fg_structure = c("PAG","VTA"),
                fg_color = c("magenta","green"),
                fg_alpha = 0.4,
                bg_structure = "root",
                bg_color = "grey",
                bg_alpha = 0.2)

##Saving 3D plot snapshots as images

plot_ccf_meshes(mesh_list,
                  fg_structure = c("MOs","TH","P"),
                  fg_color = c("orangered","skyblue","purple"),
                  bg_structure = "root")

rgl.snapshot("FIGURE.png")

##Saving 3D plot objects as interactive HTML widgets

th_str <- c("TH","LGd","LP","LGv","RT")
th_meshes <- map(th_str, ccf_2017_mesh)

names(th_meshes) <- th_str

plot_ccf_meshes(th_meshes,
                fg_structure = c("LGd","LGv","LP","RT"),
                fg_color = c("orangered","skyblue","purple","darkgreen"),
                bg_structure = c("TH"))

th_widget <- rglwidget(scene3d(), # Captures the current 3D rgl plot
                       width = 600, 
                       height = 600)

saveWidget(th_widget, "th_structure_widget.html")

##Animation

library(magick)
structures <- c("VTA","PAG","IPN","IF")
mesh_list <- map(structures, ccf_2017_mesh)

names(mesh_list) <- structures

plot_ccf_meshes(mesh_list,
                fg_structure = c("VTA","PAG"),
                bg_structure = "root")

anim <- spin3d(axis=c(0,1,0), # Spin on the y-axis
               rpm = 4)

movie3d(anim, 
        fps = 20, # 20 fps is fairly smooth
        duration = 5, # 5 sec = 1 rotation at 12 rpm
        movie = "newdemo", # Save as brain_demo.gif
        dir = getwd(), # Output directory - will make a lot of temporary files.
        type = "gif")

