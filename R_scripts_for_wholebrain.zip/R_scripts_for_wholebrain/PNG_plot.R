##script for printing png image (as raster) and superimposed transformation grid, mask of single brain area

scale.factor <- mean(dim(regi$transformationgrid$mx)/c(regi$transformationgrid$height,regi$transformationgrid$width))
xMax <- max(c(regi$transformationgrid$mx, regi$transformationgrid$mxF),na.rm = TRUE) * (1/scale.factor)
xMin <- min(c(regi$transformationgrid$mx, regi$transformationgrid$mxF),na.rm = TRUE) * (1/scale.factor)
yMax <- max(c(regi$transformationgrid$my, regi$transformationgrid$myF),na.rm = TRUE) * (1/scale.factor)
yMin <- min(c(regi$transformationgrid$my, regi$transformationgrid$myF),na.rm = TRUE) * (1/scale.factor)

main.title <- basename(regi$outputfile)
#PLOT

plot(c(xMin, xMax), c(yMin, yMax), ylim = c(yMax, yMin), 
     xlim = c(xMin, xMax), asp = 1, axes = F, xlab = "", 
     ylab = "", col = 0, main = main.title, font.main = 1)
polygon(c(0, rep(regi$transformationgrid$width,2), 0), c(0, 0, rep(regi$transformationgrid$height,2)))
img <- paste(regi$outputfile, "_undistorted.png", sep = "")
img <- readPNG(img)
img = as.raster(img[, ])
img <- apply(img, 2, rev)
rasterImage(img, 0, 0, regi$transformationgrid$width,regi$transformationgrid$height)

#for drawing border
    lapply(1:regi$atlas$numRegions, function(x) {
      polygon(regi$atlas$outlines[[x]]$xrT/scale.factor, 
              regi$atlas$outlines[[x]]$yrT/scale.factor, 
              border = border)})
    lapply(1:regi$atlas$numRegions, function(x) {
      polygon(regi$atlas$outlines[[x]]$xlT/scale.factor, 
              regi$atlas$outlines[[x]]$ylT/scale.factor, 
              border = border)})
#for drawing grid
    hei <- dim(regi$transformationgrid$mx)[1]
    wid <- dim(regi$transformationgrid$mx)[2]
    lapply(seq(1, hei, by = 100), function(x) {
      lines(regi$transformationgrid$mx[x, ]/scale.factor, 
            regi$transformationgrid$my[x, ]/scale.factor, 
            col = grid.color) })
    lines(regi$transformationgrid$mx[hei, ]/scale.factor, 
          regi$transformationgrid$my[hei, ]/scale.factor, 
          col = grid.color)
    lapply(seq(1, wid, by = 100), function(x) {
      lines(regi$transformationgrid$mx[, x]/scale.factor, 
            regi$transformationgrid$my[, x]/scale.factor, 
            col = grid.color) })
      lines(regi$transformationgrid$mx[, wid]/scale.factor, 
            regi$transformationgrid$my[, wid]/scale.factor, 
            col = grid.color)
  
#for drawing single brain structure (look at intensityscaleplot for how to select the area)

  lapply(k, function(x) {
    polygon(regi$atlas$outlines[[x]]$xrT/scale.factor, 
            regi$atlas$outlines[[x]]$yrT/scale.factor, 
            border = "black") })
  lapply(k, function(x) {
    polygon(regi$atlas$outlines[[x]]$xlT/scale.factor, 
            regi$atlas$outlines[[x]]$ylT/scale.factor,
            border = "black") })