### colocr function
if(!require('imager')) {
  install.packages('imager')
  library('imager')
}


if(!require('colocr')) {
  install.packages('colocr')
  library('colocr')
}
  
##NOTE, I will need to updat r TO VERSION 4.0, trying on Stormtrooper


## A plot 3D example data.
data("twolines")
library("rgl")
plot3d(twolines[,c("x","y","z")], type='s', size=0.7, col = twolines$membership)
aspect3d("iso")

setwd("F:/LH_ASDS/Done/LH_ASDS_analysis/")


##extract from the datasets the x/y of each segmented neuron for a specific brain area both for trap and cfos
library("dplyr")
PL_TRAP_neurons<-master_trap_data[grepl("Prelimbic",master_trap_data$name),]
PL_CFOS_neurons<-master_cfos_data[grepl("Prelimbic",master_cfos_data$name),]
coloc_data<-PL_TRAP_neurons[,1:4]
coloc_data$channel<-"red"
coloc_data2<-PL_CFOS_neurons[,1:4]
coloc_data2$channel<-"green"
coloc_data<-rbind(coloc_data,coloc_data2)
plot3d(coloc_data[,c("x","y","AP")], type='s', size=0.7, col = coloc_data$channel)

#list of brain areas you want to look at
areas_in_plate<- c(972, 295, 359,536,165,958,493)
ROI<- list()
for (i in areas_in_plate) {
  print(i)
  name_areas<- acronym.from.parent(i)
  ROI<-name_areas
  for (ii in ROI) {
    print(ii)
    TRAP_neurons<-master_trap_data[grepl(ii,master_trap_data$acronym),]
    CFOS_neurons<-master_cfos_data[grepl(ii,master_cfos_data$acronym),]
    coloc_data<-TRAP_neurons[,1:4]
    coloc_data$channel<-"red"
    coloc_data2<-CFOS_neurons[,1:4]
    coloc_data2$channel<-"green"
    coloc_data<-rbind(coloc_data,coloc_data2)
    tablename=paste0(ii,"_coloc_neurons")
    assign(tablename,coloc_data)
  }

}
#look for repeated x values for each animal

list_coloc<-ls(envir=.GlobalEnv, pattern = "coloc_neurons" )

for (dt in list_coloc) {
  print(dt)
  dt1<-get(dt)
  for (i in unique(dt1$animal)) {
    coloc_data1<-dt1[dt1$animal==i,]
    coloc_groupx<- coloc_data1%>%group_by(x)%>%filter(n() > 1)
    plot3d(coloc_groupx[,c("x","y","AP")], type='s', size=0.4, col = coloc_groupx$channel)
    filename=paste0(i,"_",dt,".png")
    snapshot3d(filename)
  }
  
}

for (i in unique(coloc_data$animal)) {
  coloc_data1<-coloc_data[coloc_data$animal==i,]
  coloc_groupx<- coloc_data1%>%group_by(x)%>%filter(n() > 1)
  plot3d(coloc_groupx[,c("x","y","AP")], type='s', size=0.4, col = coloc_groupx$channel)
  filename=paste0(i, ".png")
  snapshot3d(filename)
}


