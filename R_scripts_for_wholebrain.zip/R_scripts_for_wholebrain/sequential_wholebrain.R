if (!require(devtools))
  install.packages("devtools")

quartz<-function(width,height){windows(width, height)}

library(wholebrain)
library(tidyr)
library(data.table)

#Sequential script for all the tif file in the folder

folder="C:/Users/Mangana/Downloads/D008_M4_TIFF/c01_trap/"
#find out how many images we have and their location
images<- get.images(folder)
length(images)
#initialize vector
filename <- rep(1,length(images))
filename<- get.images(folder)
head(filename)
#filename<- tail(filename, 28)

##brain coordinates based on bregma from openbrainmap.org
#create a list of coordinates for each slide, i.e. an excel file "Coordinate" to import
library(readxl)
Coordinates <- read_excel("Coordinates.xlsx",range = "A1:B138", col_names = FALSE)
names(Coordinates)<-c('images','coor')
smp.coord <- as.numeric(Coordinates$coor)


#Seg and regi for first file(NB "i" can be different if you don't start with the first image)
ii=1
i=1       
filename[i]
#seg<-segment(filename[i])
#  plot(seg$soma$x, seg$soma$y, ylim=rev(range(seg$soma$y)), asp=1)
quartz()
#set filter$resize nr from 0.01 to 0.1
seg$filter$resize<- 0.085
regi<-registration(filename[i], coordinate = smp.coord[ii], filter = seg$filter)
#change the filter if the mask is not proportional
n<-readline(prompt="Enter skip 1: " )
seg$filter$resize<-as.numeric(n)
#change corrpoints
regi<-change.corrpoints(regi, 1:17)
regi<-change.corrpoints(regi, 18:23)
#remove corrpoints if parts of the brain are missing
regi<-remove.corrpoints(regi, 32)
#rerun registration after change or remove or add points
regi<-registration(filename[i], coordinate = smp.coord[ii], filter=seg$filter, correspondance = regi)
#add corr.points
regi<-add.corrpoints(regi)
#rerun registration
regi<-registration(filename[i], coordinate = smp.coord[ii], filter=seg$filter, correspondance = regi)
#create dataset and save temporary files for later analysis
dataset<-inspect.registration(regi, seg, soma = TRUE, forward.warps = TRUE, batch.mode = TRUE)
dev.copy(pdf, paste0(tools::file_path_sans_ext(basename(filename[i])), '.pdf'))
dev.off()

if (exists('datasets')) {
  print("datasets exist!")
  datasets<-rbind(datasets, dataset)
  save(file= paste0(tools::file_path_sans_ext(basename(filename[i])), '.Rdata'),seg, regi, dataset,datasets)
}else{
  datasets<- dataset
  save(file= paste0(tools::file_path_sans_ext(basename(filename[i])), '.Rdata'),seg, regi, dataset,datasets)
}

##Loop for segmentation only (if you want to do it fast and focus on registration later)
for (c in filename[2:5]) {
  #rm(seg, regi)
  seg<-segment(c)
  save(file= paste0(tools::file_path_sans_ext(basename(c)), '.Rdata'), seg) 
}

##Loop for registration only (after creating seg files and save as Rdata)
#recreate datasets if crashed before, check where your Rdata are(i.e. in ~)
Rdatafiles<-list.files(pattern="*.Rdata")
length(Rdatafiles)
ii=1
for (c in filename[2:5]) {
  #rm(seg, regi)
  load(file=Rdatafiles[ii])
  ii=ii+1
  n<-readline(prompt="Enter resize factor: " )
  seg$filter$resize<-as.numeric(n)
  smp.coord[ii]
  quartz()
  regi<-registration(c, coordinate = smp.coord[ii], filter =seg$filter)
  #change the filter if the mask is not proportional
  n<-readline(prompt="Enter resize factor: " )
  seg$filter$resize<-as.numeric(n)
  # quartz()
  regi<-registration(c, coordinate = smp.coord[ii], filter =seg$filter)
  #change corrpoints
  pos1<-readline(prompt="Which point location are wrong? ")
  if (pos1 == 0){
    print("save files")
  } else {
    print("change them")
    n1<-as.numeric(pos1)
    regi<-change.corrpoints(regi, 1:n1)
    #rerun registration
    regi<-registration(c, coordinate = smp.coord[ii], filter=seg$filter, correspondance = regi)
  }
  #remove corr.points
  n1<-readline(prompt=" you want to remove points? ")
  if (n1 != "no") {
    print("add points and right click when finish!")
    regi<-remove.corrpoints(regi,as.numeric(n1))
    regi<-registration(c, coordinate= smp.coord[ii], filter=seg$filter, correspondance = regi)
  }
  #add corr.points
  n2<-readline(prompt=" you want to add points? ")
  if (n2 == "yes") {
    print("add points and right click when finish!")
    regi<-add.corrpoints(regi)
    regi<-registration(c, coordinate= smp.coord[ii], filter=seg$filter, correspondance = regi)
  }
  
  #save output files
  dataset<-inspect.registration(regi, seg, soma = TRUE, forward.warps = TRUE, batch.mode = TRUE)
  dev.copy(pdf, paste0(tools::file_path_sans_ext(basename(c)), '.pdf'))
  save(file= paste0(tools::file_path_sans_ext(basename(c)), '.Rdata'), seg, regi, dataset,datasets)
  datasets<-rbind(datasets, dataset)
  dev.off()
}

            ###Loop for segmentation and registration all files###
             #make sure to change the index (:) according to your images
ii=1
for (c in filename[2:128]) {
  #rm(seg, regi)
  ii=ii+1
  load(file=Rdatafiles[ii])
  seg<-segment(c)
  #  plot(seg$soma$x, seg$soma$y, ylim=rev(range(seg$soma$y)), asp=1)
  n<-readline(prompt="Enter resize factor: " )
  seg$filter$resize<-as.numeric(n)
  smp.coord[i]
  quartz()
  regi<-registration(c, coordinate = smp.coord[ii], filter =seg$filter)
  #change the filter if the mask is not proportional
  n<-readline(prompt="Enter resize factor: " )
  seg$filter$resize<-as.numeric(n)
  # quartz()
  regi<-registration(c, coordinate = smp.coord[ii], filter =seg$filter)
  #change corrpoints
  pos1<-readline(prompt="Which point location are wrong? ")
  if (pos1 == 0){
    print("save files")
  } else {
    print("change them")
    n1<-as.numeric(pos1)
    regi<-change.corrpoints(regi, 1:n1)
    #rerun registration
    regi<-registration(c, coordinate = smp.coord[ii], filter=seg$filter, correspondance = regi)
  }
  
  #add corr.points
  n2<-readline(prompt=" you want to add points? ")
  if (n2 == "yes") {
    print("add points and right click when finish!")
    regi<-add.corrpoints(regi)
    regi<-registration(c, coordinate= smp.coord[ii], filter=seg$filter, correspondance = regi)
  }
  
  #save output files
  dataset<-inspect.registration(regi, seg, soma = TRUE, forward.warps = TRUE, batch.mode = TRUE)
  dev.copy(pdf, paste0(tools::file_path_sans_ext(basename(c)), '.pdf'))
  save(file= paste0(tools::file_path_sans_ext(basename(c)), '.Rdata'), seg, regi, dataset,datasets)
  datasets<-rbind(datasets, dataset)
  dev.off()
}


                                   ###END OF LOOP###


#to plot in 3D
glassbrain(datasets,device = FALSE, cex = 3, col = "region")
#move around the rbian to a position you like. (you can save the position for later by using position <- par3d() )
#to make a high resolution rendering set high.res flag to TRUE and then set device = FALSE so we do not open a new window but use the old one.
glassbrain(datasets, high.res =TRUE, device =FALSE)
#save the 3D plot into a PNG file
rgl.snapshot('D6.png')
#to make a video with different spinning orientation and save it as a gif
movie3d(duration = 15, movie = "movie", spin3d(axis = c(1,0,0), rpm = 5),dir= getwd())
movie3d(duration = 15, movie = "movie", spin3d(axis = c(0,1,0), rpm = 5))
movie3d(duration = 15, movie = "movie", spin3d(axis = c(0,0,1), rpm = 5))

#show cell counts by region and sort them.
cell.count <- table(datasets$acronym)
cell.count <- sort(cell.count)
cell.count

#show cell counts by region times hemisphere.
laterality <- table(datasets$acronym, datasets$right.hemisphere)
laterality

#plot a schematic of each slide
schematic.plot(dataset)

#make a web-based map
pixel.resolution.in.microns <- 2
makewebmap(c, filter = seg$filter, registration = regi, dataset = dataset, folder.name = NULL, scale = pixel.resolution.in.microns)

#to load this data simply use:
load('mydata.RData')

#recreate datasets if crashed before, check where your Rdata are(i.e. in ~)
Rdatafiles<-list.files(pattern="*.Rdata")
length(Rdatafiles)
for (i in Rdatafiles[1:length(Rdatafiles)]) {load(i); datasets<-rbind(datasets, dataset)}
#if you need just to bind some use specific index for i
for (i in Rdatafiles[81:97]) {load(i); datasets<-rbind(datasets, dataset)}
#forcreate the list of coord used for each registered section
smp.coord<-data.frame()
ii=0
for (i in Rdatafiles[1:length(Rdatafiles)]) {load(i);ii=ii+1; smp.coord[ii,1]<-regi$coordinate}
row.names(smp.coord)<-Rdatafiles
names(smp.coord)<-"coor"
#save as Excel spread.sheet
write.table(datasets, file='C3_exp_data.csv', sep=',', row.names =FALSE)

for (i in 1:length(Rdatafiles)) {
  load(Rdatafiles[i])
  c=paste0(folder1,tools::file_path_sans_ext(basename(Rdatafiles[i])), ".", file_ext(filename[i]))
  regi<-registration(c, coordinate = smp.coord[i], filter=seg$filter, correspondance = regi)
  score<-readline(prompt="Is the registration wrong? ")
  if (score == "y"){
    print(c)
  } 

}


###to run only segmentation and save the Rdata files
for (c in filename[1:length(filename)]) {
  seg<-segment(c)
  save(file= paste0(tools::file_path_sans_ext(basename(c)), '.Rdata'), seg)
}

Rdatafiles<-list.files(pattern="*.Rdata")
length(Rdatafiles)

###to run registration after segmentation
redo.list = c()
ii=103
#for (c in Rdatafiles[1:length(Rdatafiles)]) {
for (i in Rdatafiles[104:128]) {  
  load(i)
  ii=ii+1
 # n<-readline(prompt="Enter resize factor: " )
 # seg$filter$resize<-as.numeric(n)
  seg$filter$resize<-0.1
  seg$filter$Max<-2500
  smp.coord[ii]
  quartz()
  regi<-registration(filename[ii], coordinate = smp.coord[ii], filter =seg$filter)
  #change the filter if the mask is not proportional
  # n<-readline(prompt="Enter resize factor: " )
  # seg$filter$resize<-as.numeric(n)
  # quartz()
  # regi<-registration(filename[ii], coordinate = smp.coord[ii], filter =seg$filter)
  #change corrpoints
  point1<-readline(prompt="Which point location are wrong? first point... ")
  if (point1 == 0){
    print("save files")
  } else {
    print("change them")
    point2<-readline(prompt="second point of the range? ")
    n1<-as.numeric(point1)
    n2<-as.numeric(point2)
    regi<-change.corrpoints(regi, n1:n2)
    #rerun registration
    regi<-registration(filename[ii], coordinate = smp.coord[ii], filter=seg$filter, correspondance = regi)
  }
  #remove points
  n3<-readline(prompt="do you want to remove points? first point... ")
  if (n3 == 0){
    print("save files")
  } else {
    print("remove them")
    n4<-readline(prompt="second point of the range? ")
    n3<-as.numeric(n3)
    n4<-as.numeric(n4)
  regi<-remove.corrpoints(regi,n3:n4)
  }
  #add corrpoints
  addpoint<-readline(prompt="how many points you want to add? ")
  if (addpoint == 0){
    print("save files")
  } else {
    print("adding points")
    n1<-as.numeric(addpoint)
    regi<-add.corrpoints(regi,n1)
    #rerun registration
    regi<-registration(filename[ii], coordinate = smp.coord[ii], filter=seg$filter, correspondance = regi)
  }
  #do not continue the registration
  res<-readline(prompt="would you redo it manually? y/n \n")
  if (res == "y"){
    redo.list<-c(redo.list, c(filename[ii]))
  } else {
    #save output files
    print("save files")
    dataset<-inspect.registration(regi, seg, soma = TRUE, forward.warps = TRUE, batch.mode = TRUE)
    dev.copy(pdf, paste0(tools::file_path_sans_ext(basename(i)), '.pdf'))
    if (exists('datasets')) {
      print("datasets exist!")
      datasets<-rbind(datasets, dataset)
    }else
      datasets<- dataset
  }
  datasets<-rbind(datasets, dataset)
  save(file= paste0(tools::file_path_sans_ext(basename(i)), '.Rdata'), seg, regi, dataset,datasets)
  
  
  dev.off()
  
  
}
