z_value<-function (x,list.values) 
{
        mean_value<-mean(list.values)
        st_dev<-sd(list.values)
        z<-(x-mean_value)/st_dev
        return(z)
}



library(RColorBrewer)
#i.e.brewer.pal(n=9, name = "RdBu")
library(wesanderson)
#i.e.wes_palette(n = 5, name = 'FantasticFox1')
library(cluster)    # clustering algorithms
library(factoextra) # clustering algorithms & visualization

                            #################SI Clustering#####################


#read the file with SI scores and Corner Ratio
df_SI = read_excel("C:/Users/Mangana/Dropbox (Dumitriu Lab)/Dumitriu Lab Team Folder/Alessia/Learned_helplessness/LH_SI_October/SI_Zscores.xlsx")
View(df_SI)
#select the Column you want and work on the z-scores or normal scores
df1<-df_SI[,2:5]
df1<-df1[-4]
df1<-df1[-2]
df1<-na.omit(df1)
#df1<-scale(df1) not necessary,is it already done by the fviz function?

#Elbow Method for finding the optimal number of clusters for SI
fviz_nbclust(df1, kmeans, method = "wss") +
        geom_vline(xintercept = 2, linetype = 2) + # add line for better visualisation
        labs(subtitle = "Elbow method") # add subtitle

#Silhouette method
fviz_nbclust(df1, kmeans, method = "silhouette") +
        labs(subtitle = "Silhouette method")

#k-means algorithm with 2 centers, run 25 times
k2<-kmeans(df1, centers = 2, nstart = 25)
results <- kmeans(df1, 2, nstart = 25)
results$size
results$cluster
results
#visualize results
fviz_cluster(k2, data = df1)


#Isa plot with no x and y-axis limits modified for 2 clusters
vcol <- c("black","red")
par(xpd = T, mar = par()$mar + c(0,0,0,7))
plot(df1[,1:2], 
     col = vcol[results$cluster],
     ylab="Corner Ratio",
     xlab="SI Score")
legend(2, 2,
       c("Susceptible ", "Resilient (R)", "S centroid", "R centroid"),
       col = c("red", "black", "red", "black"),
       pch=c(1, 1, 17, 17),
       cex = 0.8)
par(mar=c(5, 4, 4, 2) + 0.1)
results$centers
points(x = results$centers[1,1] , y= results$centers[1,2], type="p", pch=2, col="black", cex=2)
points(x = results$centers[2,1] , y= results$centers[2,2], type="p", pch=2, col="red", cex=2)

#Isa plot with x and y-axis limits modified for 2 clusters
vcol <- c("black","red")
par(xpd = T, mar = par()$mar + c(0,0,0,7))
plot(df1[,1:2], 
     col = vcol[results$cluster],
     pch=c(20),
     cex=c(2),
     main="LH + SI C-57",
     xlim=c(min(df1[,1]), max(df1[,1])),
     ylim=c(min(df1[,2]), max(df1[,2])),
     ylab="Corner Ratio",
     xlab="SI Score",
     bty= "l")
#legend(2, 2,
#       c("Susceptible ", "Resilient (R)", "S centroid", "R centroid"),
#       col = c("red", "black", "red", "black"),
#       pch=c(20, 20, 2, 2),
#       cex = 0.8)
par(mar=c(5, 4, 4, 2) + 0.1)
results$centers
points(x = results$centers[1,1] , y= results$centers[1,2], type="p", pch=2, col="black", cex=2)
points(x = results$centers[2,1] , y= results$centers[2,2], type="p", pch=2, col="red", cex=2)
results$cluster

# k-means algorithm with 3 centers, run 25 times
kmeans(df1, centers = 3, nstart = 25)
k3 <- kmeans(df1, centers = 3, nstart = 25)
results <- kmeans(df1, 3, nstart = 25)
results$size
results$cluster
results

#plot for 3 clusters
vcol <- c("black","blue","red")
par(xpd = T, mar = par()$mar + c(0,0,0,7))
plot(df1[,1:2], 
     col = vcol[results$cluster],
     pch=c(20),
     cex=c(2),
     main="LH + SI C-57",
     xlim=c(min(df1[,1]),max(df1[,1])),
     ylim=c(min(df1[,2]),max(df1[,2])),
     ylab="Corner Ratio",
     xlab="SI Score",
     bty= "l")
#legend(2, 2,
#       c("Susceptible ", "Resilient (R)", "S centroid", "R centroid"),
#       col = c("red","blue","black", "red","blue","black"),
#       pch=c(20, 20, 2, 2),
#       cex = 0.8)
par(mar=c(5, 4, 4, 2) + 0.1)
results$centers
points(x = results$centers[1,1] , y= results$centers[1,2], type="p", pch=2, col="black", cex=2)
points(x = results$centers[2,1] , y= results$centers[2,2], type="p", pch=2, col="blue", cex=2)
points(x = results$centers[3,1] , y= results$centers[3,2], type="p", pch=2, col="red", cex=2)
results$cluster


k4 <- kmeans(df, centers = 4, nstart = 25)
results <- kmeans(df1, 4, nstart = 25)
results$size
results$cluster
results

#plot for 4 clusters
vcol <- c("black","grey","blue","red")
par(xpd = T, mar = par()$mar + c(0,0,0,7))
plot(df1[,1:2], 
     col = vcol[results$cluster],
     pch=c(20),
     cex=c(2),
     main="LH + SI C-57",
     xlim=c(min(df1[,1]),max(df1[,1])),
     ylim=c(min(df1[,2]),max(df1[,2])),
     ylab="Corner Ratio",
     xlab="SI Score",
     bty= "l")
#legend(2, 2,
#       c("Susceptible ", "Resilient (R)", "S centroid", "R centroid"),
#       col = c("red","grey","blue","black", "red","grey","blue","black"),
#       pch=c(20, 20, 2, 2),
#       cex = 0.8)
par(mar=c(5, 4, 4, 2) + 0.1)
results$centers
points(x = results$centers[1,1] , y= results$centers[1,2], type="p", pch=2, col="black", cex=2)
points(x = results$centers[2,1] , y= results$centers[2,2], type="p", pch=2, col="grey", cex=2)
points(x = results$centers[3,1] , y= results$centers[3,2], type="p", pch=2, col="blue", cex=2)
points(x = results$centers[4,1] , y= results$centers[4,2], type="p", pch=2, col="red", cex=2)
results$cluster

#try always to use different K to compare results
k5 <- kmeans(df, centers = 5, nstart = 25)

# plots all cluster combination to compare
p1 <- fviz_cluster(k2, geom = "point",  data = df) + ggtitle("k = 2")
p2 <- fviz_cluster(k3, geom = "point",  data = df) + ggtitle("k = 3")
p3 <- fviz_cluster(k4, geom = "point",  data = df) + ggtitle("k = 4")
p4 <- fviz_cluster(k5, geom = "point",  data = df) + ggtitle("k = 5")

library(gridExtra)
grid.arrange(p1, p2, p3, p4, nrow = 2)

df_SI$Cluster<-results$cluster
write.csv( df_SI, file = 'df_SI.csv')



          #################LH Clustering#####################

#create a file with Failures and Escape Latency with the script "extract_datatable_LHtextfiles"
View(df_LH)
#or read the file with Failures and Escape Latency computed in Excel
df_LH = read_excel("C:/Users/Mangana/LH_scores.xlsx")
View(df_LH)
#select the Column you want
df2<-df_LH[,2:3]
df2<-na.omit(df2)
#df2<-scale(df2)

#if you have merged file from more waves
View(df_LH_merged)
#or read the file with Failures and Escape Latency computed in Excel
df_LH_merged = read_excel("C:/Users/Mangana/LH_scores.xlsx")
#select the Column you want
df2<-df_LH_merged[,2:3]
df2<-na.omit(df2)
#df2<-scale(df2)


#Elbow Method for finding the optimal number of clusters for LH
fviz_nbclust(df2, kmeans, method = "wss") +
        geom_vline(xintercept = 2, linetype = 2) + # add line for better visualisation
        labs(subtitle = "Elbow method") # add subtitle

#Silhouette method
fviz_nbclust(df2, kmeans, method = "silhouette") +
        labs(subtitle = "Silhouette method")

#k-means algorithm with 2 centers, run 20 times
k2<-kmeans(df2, centers = 2, nstart = 25)
results <- kmeans(df2, 2, nstart = 25)
results$size
results$cluster
results
#visualize quickly the results
fviz_cluster(k2, data = df2)


#Plot with x and y-axis limits modified for 2 clusters
vcol <- c( "darkgoldenrod1","darkcyan")
par(xpd = T, mar = par()$mar + c(0,0,0,7), new=TRUE)
plot(df2[,1:2], 
     col = vcol[results$cluster],
     pch=c(20),
     cex=c(2),
     #  main="LH + SI C-57",
     xlim=c(0,30),
     ylim=c(0,10),
     ylab="Escape latency (s)",
     xlab="Failures",
     bty= "l")
legend(31, 12,
       c("Helpless (H) ", "Resilient (R)", "H centroid","R centroid"),
       col = c("darkcyan","darkgoldenrod1","darkcyan","darkgoldenrod1"),
       pch=c(20, 20, 2, 2),
       cex = 1.2)
par(mar=c(5, 4, 4, 2) + 0.1)
#results$centers
points(x = results$centers[1,1] , y= results$centers[1,2], type="p", pch=2, col="darkgoldenrod1", cex=2)
points(x = results$centers[2,1] , y= results$centers[2,2], type="p", pch=2, col="darkcyan", cex=2)
results$cluster

# k-means algorithm with 3 centers, run 20 times
kmeans(df2, centers = 3, nstart = 25)
k3 <- kmeans(df2, centers = 3, nstart = 25)
results <- kmeans(df2, 3)
results$size
results$cluster
results

#plot for 3 clusters
vcol <- c( "darkgoldenrod1","cadetblue3","darkcyan")
par(xpd = T, mar = par()$mar + c(0,0,0,7), new=TRUE)
plot(df2[,1:2], 
     col = vcol[results$cluster],
     pch=c(20),
     cex=c(2),
   #  main="LH + SI C-57",
     xlim=c(0,30),
     ylim=c(0,10),
     ylab="Escape latency (s)",
     xlab="Failures",
     bty= "l")
legend(31, 12,
       c("Helpless (H) ","Less Helpless", "Resilient (R)", "H centroid", "H less centroid","R centroid"),
       col = c("darkcyan","cadetblue3","darkgoldenrod1","darkcyan","cadetblue3","darkgoldenrod1"),
       pch=c(20, 20, 20, 2, 2, 2),
       cex = 1.2)
par(mar=c(5, 4, 4, 2) + 0.1)
results$centers
points(x = results$centers[1,1] , y= results$centers[1,2], type="p", pch=2, col="darkgoldenrod1", cex=3)
points(x = results$centers[2,1] , y= results$centers[2,2], type="p", pch=2, col="cadetblue3", cex=3)
points(x = results$centers[3,1] , y= results$centers[3,2], type="p", pch=2, col="darkcyan", cex=3)
results$cluster

#if you want to overlap the controls
df1<-df_LH_merged_control[,2:3]
df1<-na.omit(df1)
par(xpd = T, mar = par()$mar + c(0,0,0,7), new=TRUE)
plot(df1[,1:2], 
     col = "black",
     pch=c(20),
     cex=c(2),
     #  main="LH + SI C-57",
     xlim=c(0,30),
     ylim=c(0,10),
     ylab="Escape latency (s)",
     xlab="Failures",
     bty= "l")
legend(31, 5.5,
       c("Control (C)"),
       col = c("black"),
       pch=c(20),
       cex = 1.2)
par(mar=c(5, 4, 4, 2) + 0.1)

#try always to use different K to compare results
k4 <- kmeans(df2, centers = 4, nstart = 25)
k5 <- kmeans(df2, centers = 5, nstart = 25)

# plots all cluster combination to compare
p1 <- fviz_cluster(k2, geom = "point",  data = df2) + ggtitle("k = 2")
p2 <- fviz_cluster(k3, geom = "point",  data = df2) + ggtitle("k = 3")
p3 <- fviz_cluster(k4, geom = "point",  data = df2) + ggtitle("k = 4")
p4 <- fviz_cluster(k5, geom = "point",  data = df2) + ggtitle("k = 5")

library(gridExtra)
grid.arrange(p1, p2, p3, p4, nrow = 2)

df_LH$Cluster<-results$cluster
write.csv( df_LH, file = 'df_LH.csv')


#z-score analysis
df_LH_merged%>%arrange(animal)
df_SI_merged%>%arrange(animal)
LH_SI_Zscore<-df_SI_merged[,3:5]
LH_SI_Zscore<-LH_SI_Zscore[-2]
LH_SI_Zscore$`LH FAILURES Z-SCORE`<-df_LH_merged$Failures
LH_SI_Zscore$`LH LATENCY Z-SCORE`<-df_LH_merged$Latency

for (i in 1:dim(LH_SI_Zscore)[1]) {
         LH_SI_Zscore$SI_Z[i]<-z_value(LH_SI_Zscore$SI[i],LH_SI_Zscore$SI)
    }

for (i in 1:dim(LH_SI_Zscore)[1]) {
         LH_SI_Zscore$Failures_Z[i]<-z_value(LH_SI_Zscore$Failures[i],LH_SI_Zscore$Failures)
     }

for (i in 1:dim(LH_SI_Zscore)[1]) {
        LH_SI_Zscore$Latency_Z[i]<-z_value(LH_SI_Zscore$Latency[i],LH_SI_Zscore$Latency)
    }
# for (i in 1:dim(df_SI)[1]) {
#         z_value(df_SI$`CORNER RATIO`[i],df_SI$`CORNER RATIO`)->LH_SI_Zscore$`CR Z-SCORE`[i]
#     }

#combined z-score
for (i in 1:dim(LH_SI_Zscore)[1]) {
            LH_SI_Zscore$Z_LH_COMBINED[i]<-(LH_SI_Zscore$Failures_Z[i] + LH_SI_Zscore$Latency_Z[i])/2
         }
#correlation tests and plots
library(ggpubr)
cor.test(LH_SI_Zscore$SI_Z,LH_SI_Zscore$Z_LH_COMBINED, method = "pearson")
ggscatter(LH_SI_Zscore, x="SI Z-SCORE", y="Z_LH_COMBINED", add = "reg.line", conf.int = TRUE,cor.coef = TRUE, cor.method = "pearson")