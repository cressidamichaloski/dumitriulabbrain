#create the datasets if you are happy with all the merged results.Change the path on line 4 and the rootname of Rdatafiles on line 5.
#Change also the name of the new csv file on line 9
remove(dataset, datasets)
setwd("C:/Users/Mangana/Documents/Rdatafiles_D002_F1/mergedRdata/")
Rdatafiles_c02_m<-list.files(pattern="*_merged.Rdata")
load(Rdatafiles_c02_m[1])
datasets<-dataset
for (i in Rdatafiles_c02_m[2:length(Rdatafiles_c02_m)]) {load(i); datasets<-rbind(datasets, dataset)}
write.table(datasets, file = "DF_D002_F1_cfos_data.csv",row.names=TRUE, na="",col.names=TRUE, sep=",")

#if the column ML DV are missing because of the FALSE value above, temporarily create them
for (i in Rdatafiles_c02_m[28:42]) {load(i); dataset$ML<-NA; dataset$DV<-NA; save(file= i, seg1, regi1, dataset)}

                
                           ###creation of master.dataset/removing NA fields/some count and plots functions
install.packages("dplyr")


library(dplyr)
library(tidyr)
library(ggplot2)
library(colorspace)
library(data.table)


datasets1$animal<- "DOO1"
datasets2$animal<- "DOO2"
datasets3$animal<- "DOO3"
master.data<-rbind(datasets1,datasets2,datasets3)
#remove NA
master.data <- master.data[!(master.data$color == '#000000'),]
#Creat group col for both phenothype and exp and populate with the correct value
master.data$group<- NA
master.data$group[master.data$animal=="D9"]<-"def"
master.data$exp<- NA
master.data$exp[master.data$animal=="D9"]<-"ESARE"
#if one specific subset of the dataset is NA and you want to replace with a value
master.data$animal[is.na(master.data$animal)] <- "D2"

#to remove duplicate from a data.table(WARNING not from dataset)
master.data<-unique(master.data, by = "colname")
#to order alphabetically the brain area
master.data<-master.data[order(master.data$acronym),]


#ROI plotting for animal and group (ex-> BLA and TH)
dataplot<- roi.cell.count(master.data, rois = c('BLAa','TH'))
cell_count_group1$animal->id #copy the column with animal name from whatever dataset
cell_count_group1$group->group #copy the column with animal group from whatever dataset
dataplot<-add.group(dataplot,subjectID =id, group =group)
df1<-data.summary(dataplot, varname='cell.count', groupnames=c('acronym','group'))
df1<-rename(df1, c('acronym' = 'region'))
p <- ggplot(df1, aes(x=region, y=cell.count, fill=group)) + 
  geom_bar(stat="identity", position=position_dodge()) +
  geom_errorbar(aes(ymin=cell.count-err, ymax=cell.count+err), width=.2, position=position_dodge(.9))
p + scale_fill_brewer(palette="Paired") + theme_classic()


#subset your data with grep(i.e take only data from animal CTR in dataplot)
control_test <- grep("CTR", dataplot$group)


###for heat maps
library(heatmap.plus)
library(RColorBrewer)
#first function list of colours for condition
condition_colors<- unlist(lapply(dataplot$group, function(x){
  if(grepl("CTR", x)) '#E74C3C'
  else if(grepl("DEF",x)) '#2980B9'
  
}))

for (i in list_seg[1:length(list_seg)]) {
  seg_somax<-append()
}






