##Script for find the coordinates of single brain area after registration and plot them in Tiff format###

quartz<-function(width,height){windows(width, height)}
library(wholebrain)
library(tiff)

folder="F:/LH_ASDS/Done/C004_M1/"
#Load dataset and regi (THIS WILL OVERWRITE ANY EXISTING regi OR dataset NAMED OBJECTS)
setwd(folder)
Rdatafiles<-list.files(pattern = "*merged.Rdata")
length(Rdatafiles)

remove(regi,regi1)
load(file=Rdatafiles[1])
regi<-regi1

##check regi$outputfile to see where your undistorted/distorted images are, and change it
regi$outputfile
regi$outputfile<-paste0(folder,"output_",dataset$image[1],"/",basename(regi$outputfile))

##tryout the schematic plot function
schematic.plot(dataset)

##tryout the plot.registration() function
plot.registration(regi)


###PLOT ALL AREAs in the list AM 10/22/23###

for (c in Rdatafiles[1:length(Rdatafiles)]) {
  print(c)
  remove(regi,regi1)
  load(file=c)
  regi<-regi1
  ##check regi$outputfile too see where your undistorted/distorted images are
  outputfile_old<-regi$outputfile
  regi$outputfile<-paste0(folder,"output_",dataset$image[1],"/",basename(regi$outputfile))
  ##create one folder for each image where all the subfiles of the ROI will be saved
  outputfolder<-basename(regi$outputfile)
  if (!dir.exists(outputfolder)) {
    dir.create(outputfolder)
  }
  ##load in the atlas index and the atlas ontology
  data(atlasIndex, envir=environment())
  data(ontology, envir=environment())
  ##load the atlas contours
  data(EPSatlas, envir=environment())
  ##get the coordinate form your registration
  your.coordinate<-regi$coordinate
  ## there is a bug in the calculation of plate for coord 1.1 and 0.1 (because the plates 133-152 have +values from bregma)
  if (your.coordinate == "1.1") { 
    plate<-43
  } else if (your.coordinate == "0.1") {
    plate<-53
  } else {
    plate <- which(abs(your.coordinate - atlasIndex$mm.from.bregma) == min(abs(your.coordinate - atlasIndex$mm.from.bregma)))
  }
  
  #list of brain areas in the selected plate, from id nr to name
  areas_in_plate<- EPSatlas$plate.info[[plate]]$structure_id
  
  ROI<- list()
  for (i in areas_in_plate) {
    name_areas<- paste(ontology$name[which(ontology$id == i)], i)
    ROI[[i]]<-name_areas
  }
  
  ##region of interests
    region.of.interests<-list()
    region.of.interests<-macro_areas
    
 
  #PL<-dataset[which(dataset$acronym %in% get.sub.structure(region.of.interest)),]
  
  ##scale factor to your image
  scale.factor <- mean(dim(regi$transformationgrid$mx)/c(regi$transformationgrid$height, regi$transformationgrid$width))
  
  ##Loop for outline selection of all ROI if present in the plate
  
  for (i in region.of.interests) {
    print(i)
    k<-which(EPSatlas$plate.info[[plate]]$structure_id %in% id.from.acronym(i))
    if (isTRUE(k != 0)) {
      #   quartz()
      outputfilename = paste0(basename(regi$outputfile),'_',sub("/","",i),'.tiff')
      if (grepl("2/3",i)) {
           tiff(filename = file.path(outputfolder,outputfilename), res = 300, width = 2612, height = 2418)
        #tiff(filename = paste(outputfolder,paste0(basename(regi$outputfile),'_',sub("/","",i),'.tiff'),sep = "/"), res = 300, width = 2612, height = 2418)
         } 
      # else if (i == "PL2/3") {
      #   tiff(filename = paste0(basename(regi$outputfile),'PL23.tiff'), res = 300, width = 2612, height = 2418)
      # }  
      else if (grepl("4/5",i)) {
        tiff(filename = file.path(outputfolder,outputfilename), res = 300, width = 2612, height = 2418)
       }
      else {
        tiff(filename = file.path(outputfolder,outputfilename), res = 300, width = 2612, height = 2418)
      }
      
      plot.registration(regi, border = FALSE)
      lapply(k, function(x) {
        polygon(regi$atlas$outlines[[x]]$xrT/scale.factor, 
                regi$atlas$outlines[[x]]$yrT/scale.factor, 
                border = "black") })
      lapply(k, function(x) {
        polygon(regi$atlas$outlines[[x]]$xlT/scale.factor, 
                regi$atlas$outlines[[x]]$ylT/scale.factor) }) 
      dev.off()
    }
  }
}
###END###



#plot the cells in ROI i.e. thalamus
points(TH$x, TH$y, pch = 20, col = TH$color)

#plot the original atlas plate outline in real scale for right and left hemisphere

for (d in 1:96) {
  lapply(d, function(x){
    polygon(regi$atlas$outlines[[x]]$xrT,regi$atlas$outlines[[x]]$yrT, border = "red")})
}

for (d in 1:96) {
  lapply(d, function(x){
    polygon(regi$atlas$outlines[[x]]$xlT,regi$atlas$outlines[[x]]$ylT, border = "red")})
}
