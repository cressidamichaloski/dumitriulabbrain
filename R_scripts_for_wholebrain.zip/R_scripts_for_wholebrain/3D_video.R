devtools::install_github("bwlewis/rthreejs")
library(threejs)
###i.e. D6 datasets, take X,Y,AP left and right hemisphere, make X & Y coordinates of left hemisphere negative

x<- D6_dataset$x[D6_dataset$right.hemisphere == FALSE]
x2<- D6_dataset$x[D6_dataset$right.hemisphere == TRUE]
y<- D6_dataset$y[D6_dataset$right.hemisphere == FALSE]
y2<- D6_dataset$y[D6_dataset$right.hemisphere == TRUE]
x2<- x2 * -1
y2<- y2 * -1
z<- D6_dataset$AP[D6_dataset$right.hemisphere == FALSE]
z2<- D6_dataset$AP[D6_dataset$right.hemisphere == TRUE]
x<- c(x, x2)
y<- c(y, y2)
z<- c(z, z2)
color<-D6_dataset$color[D6_dataset$right.hemisphere == FALSE]
color2<-D6_dataset$color[D6_dataset$right.hemisphere == TRUE]
colorpalette<- c(color, color2)

scatterplot3js(x, y, z, size = 0.1, axis.scale = c(1,1,2), grid=FALSE, num.ticks= c(0,0,8), color=c(colorpalette))

###from glassbrain
dataset<-D6_dataset
alpha <-1
smp.AP <- rnorm(length(D6_dataset$AP), 0, (320/9.75) * 0.2)
smp.ML <- 0
color<- as.character(D6_dataset$color)
par3d(persp)
drawScene.rgl(list(VOLUMESMALL))
smp.AP <- rnorm(length(D6_dataset$AP), 0, (320/9.75) * 0.2)
smp.ML <- 0
points3d(paxTOallen(D6_dataset$AP) - 530/2 + smp.AP, (-D6_dataset$DV * 1000/25 * 0.95) - 320/2, D6_dataset$ML * 1000/25 + 
               smp.ML, col = color, size = 0.5)

points3d(paxTOallen(dataset$AP) - 530/2 + smp.AP, (-dataset$DV * 
                                                     1000/25 * 0.95) - 320/2, dataset$ML * 1000/25 + 
           smp.ML, col = color, size = cex, alpha = alpha)

scatterplot3js(x, y, z, size = 0.1, axis.scale = c(1,1,2), grid=FALSE, num.ticks= c(0,0,8), color=c(colorpalette))


